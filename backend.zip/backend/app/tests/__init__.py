"""Tests for the ChatTSC application."""
