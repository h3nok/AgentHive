"""
Lease agent implementation for handling rental and lease inquiries.

This agent specializes in lease-related questions, rental applications, and tenant support.
"""

from typing import Union, AsyncIterator, Dict, Any
import json

from app.domain.agent_factory import BaseAgent
from app.domain.schemas import RequestContext, AgentResponse, AgentType, AgentManifest
from app.adapters.llm_openai import OpenAIAdapter
from app.core.observability import get_logger, measure_tokens

logger = get_logger(__name__)


class Agent(BaseAgent):
    """Lease specialist agent implementation."""
    
    def __init__(self, agent_id: str, manifest: AgentManifest):
        super().__init__(agent_id, manifest)
        self.llm_adapter = None
        self.system_prompt = manifest.config.get(
            "system_prompt",
            "You are a lease specialist AI assistant."
        )
        self.knowledge_base = self._load_knowledge_base()
    
    async def _initialize(self) -> None:
        """Initialize the lease agent."""
        self.llm_adapter = OpenAIAdapter()
        logger.info(f"Lease agent initialized: {self.agent_id}")
    
    def _load_knowledge_base(self) -> Dict[str, Any]:
        """Load lease-specific knowledge base."""
        import os
        
        # Load synthetic lease data
        data_path = os.path.join(os.path.dirname(__file__), "../../../app/data/lease_synthetic_data.json")
        try:
            with open(data_path, 'r', encoding='utf-8') as f:
                lease_data = json.load(f)
                logger.info(f"Loaded {len(lease_data.get('leases', []))} lease records")
        except FileNotFoundError:
            logger.warning(f"Lease data file not found at {data_path}, using default knowledge base")
            lease_data = {"leases": [], "summary_statistics": {}}
        
        # Combine static knowledge with dynamic lease data
        return {
            "lease_data": lease_data,
            "lease_terms": {
                "standard_term": "12 months",
                "short_term_available": True,
                "renewal_options": ["6 months", "12 months", "24 months"]
            },
            "application_requirements": [
                "Valid ID",
                "Proof of income (3x rent)",
                "References (2 previous landlords)",
                "Credit check authorization",
                "Application fee: $50"
            ],
            "pet_policy": {
                "allowed": True,
                "deposit": "$500",
                "monthly_fee": "$50",
                "restrictions": "Max 2 pets, weight limit 50lbs"
            },
            "utilities": {
                "included": ["Water", "Trash"],
                "tenant_responsibility": ["Electricity", "Gas", "Internet"]
            }
        }
    
    def _enhance_prompt_with_knowledge(self, prompt: str) -> str:
        """Enhance the prompt with relevant knowledge base information."""
        
        enhanced = prompt
        prompt_lower = prompt.lower()
        
        # Pet policy information
        if any(term in prompt_lower for term in ["pet", "dog", "cat", "animal"]):
            enhanced += f"\n\nPet Policy: {json.dumps(self.knowledge_base['pet_policy'], indent=2)}"
        
        # Application requirements
        if any(term in prompt_lower for term in ["apply", "application", "requirements"]):
            enhanced += f"\n\nApplication Requirements: {json.dumps(self.knowledge_base['application_requirements'], indent=2)}"
        
        # Utilities information
        if any(term in prompt_lower for term in ["utility", "utilities", "included"]):
            enhanced += f"\n\nUtilities: {json.dumps(self.knowledge_base['utilities'], indent=2)}"
        
        # Lease terms
        if any(term in prompt_lower for term in ["term", "length", "duration", "renewal"]):
            enhanced += f"\n\nLease Terms: {json.dumps(self.knowledge_base['lease_terms'], indent=2)}"
        
        # Lease data queries - provide relevant lease information
        lease_data = self.knowledge_base.get("lease_data", {})
        leases = lease_data.get("leases", [])
        
        if leases and any(term in prompt_lower for term in [
            "lease", "rent", "property", "properties", "store", "expir", "renew", "tenant", "landlord", 
            "responsibility", "repair", "hvac", "roof", "parking", "square", "sqft", "nnn", "table", "list"
        ]):
            # Add summary statistics for context
            summary = lease_data.get("summary_statistics", {})
            enhanced += f"\n\nLease Portfolio Summary: {json.dumps(summary, indent=2)}"
            
            # For specific queries, add relevant lease details
            if any(term in prompt_lower for term in ["expir", "expire", "expiration"]):
                expiring_leases = [l for l in leases if l.get("lease_expiry_warning", False) or 
                                 l.get("lease_status") == "Expiring Soon"]
                if expiring_leases:
                    enhanced += f"\n\nExpiring Leases: {json.dumps(expiring_leases, indent=2)}"
            
            # For table/list requests, include sample data structure
            if any(term in prompt_lower for term in ["table", "list", "show all", "summary"]):
                # Include first 3 leases as examples
                sample_leases = leases[:3] if len(leases) > 3 else leases
                enhanced += f"\n\nSample Lease Data (showing {len(sample_leases)} of {len(leases)} total): {json.dumps(sample_leases, indent=2)}"
        
        return enhanced
    
    @measure_tokens
    async def handle(self, context: RequestContext) -> Union[AgentResponse, AsyncIterator[str]]:
        """Handle lease-related queries."""
        if not self.llm_adapter:
            raise RuntimeError("Agent not initialized")
        
        # Enhance prompt with knowledge base
        enhanced_prompt = self._enhance_prompt_with_knowledge(context.prompt.prompt)
        
        # Build conversation history
        messages = [
            {"role": "system", "content": self.system_prompt}
        ]
        
        # Add conversation history
        if context.prompt.history:
            for msg in context.prompt.history:
                messages.append({
                    "role": msg.role.value,
                    "content": msg.content
                })
        
        # Add current prompt
        messages.append({
            "role": "user",
            "content": enhanced_prompt
        })
        
        # Log the handling
        logger.info(
            "Lease agent handling request",
            request_id=context.request_id,
            has_knowledge_enhancement=enhanced_prompt != context.prompt.prompt
        )
        
        if context.prompt.stream:
            # Return streaming response
            return self._stream_response(context, messages)
        else:
            # Return complete response
            response = await self.llm_adapter.complete(
                prompt=enhanced_prompt,
                messages=messages,
                temperature=self.manifest.config.get("temperature", 0.7),
                max_tokens=self.manifest.config.get("max_tokens", 1500)
            )
            
            return AgentResponse(
                content=response.content,
                agent_id=self.agent_id,
                agent_type=AgentType.LEASE,
                metadata={
                    "model": response.model,
                    "enhanced_with_knowledge": enhanced_prompt != context.prompt.prompt
                },
                usage=response.usage,
                latency_ms=response.metadata.get("latency_ms") if response.metadata else None
            )
    
    async def _stream_response(self, context: RequestContext, messages: list) -> AsyncIterator[str]:
        """Stream response tokens for lease queries."""
        if not self.llm_adapter:
            raise RuntimeError("LLM adapter not initialized")
            
        async for chunk in self.llm_adapter.stream_complete(
            prompt=context.prompt.prompt,
            messages=messages,
            temperature=self.manifest.config.get("temperature", 0.7),
            max_tokens=self.manifest.config.get("max_tokens", 1500)
        ):
            yield chunk.content
    
    def get_capabilities(self) -> list[str]:
        """Get specialized lease capabilities."""
        base_capabilities = super().get_capabilities()
        
        # Add dynamic capabilities based on knowledge base
        additional_capabilities = []
        if self.knowledge_base.get("pet_policy", {}).get("allowed"):
            additional_capabilities.append("pet_friendly_rentals")
        
        if self.knowledge_base.get("lease_terms", {}).get("short_term_available"):
            additional_capabilities.append("short_term_leases")
        
        return base_capabilities + additional_capabilities
    
    def get_cost_estimate(self, context: RequestContext) -> float:
        """Estimate cost for lease query."""
        # Base cost from manifest
        base_cost = self.manifest.cost_per_call
        
        # Adjust based on complexity
        prompt_length = len(context.prompt.prompt)
        if prompt_length > 500:
            # Longer, more complex queries cost more
            return base_cost * 1.5
        
        return base_cost 