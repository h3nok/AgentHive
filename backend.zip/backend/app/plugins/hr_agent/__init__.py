"""HR Agent plugin initialization."""
