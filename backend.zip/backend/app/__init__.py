"""
Intelligent Router Backend Application.

An LLM-powered routing system with plugin architecture for extensible agent capabilities.
"""

__version__ = "0.1.0" 