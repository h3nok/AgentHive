import React, { useState, useCallback, lazy, Suspense } from 'react';
import { 
  Box,
  Container, 
  Toolbar,
  useTheme,
  Snackbar,
  Alert,
  CircularProgress
} from '@mui/material';
import ChatMessageList from './ChatMessageList';
import { useSelector } from 'react-redux';
import { RootState } from '../store';
import { useCanvas } from '../context/CanvasContext';
import { useMediaQuery } from '@mui/material';
import { containerStyles } from '../constants';
import { useGetSessionQuery } from '../features/chat/sessionsApi';

// Lazy load the input component since it's quite large
const AgentDrivenChatInput = lazy(() => import('./AgentDrivenChatInput'));

// Import icons (unchanged)
import SmartToyIcon from '@mui/icons-material/SmartToy';

interface ChatInterfaceProps {
  onSendMessage: (text: string, agent: string) => void;
  isLoading: boolean;
  onStopRequest?: () => void;
  drawerPadding?: number;
}

// Loading component for suspense fallback
const InputLoadingFallback = () => (
  <Box sx={{ 
    p: 2, 
    display: 'flex', 
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 2,
    bgcolor: 'background.paper',
    boxShadow: 1
  }}>
    <CircularProgress size={24} color="primary" />
  </Box>
);

const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  onSendMessage, 
  isLoading,
  onStopRequest,
  drawerPadding = 0 
}) => {
  const [selectedAgent, setSelectedAgent] = useState<string>("lease");
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  
  const theme = useTheme();
  const activeSessionId = useSelector((state: RootState) => state.chat.activeSessionId);
  const { isOpen: isCanvasOpen, width: canvasWidth } = useCanvas();
  const isSmall = useMediaQuery(theme.breakpoints.down('md'));
  
  // Trigger message fetch for active session
  useGetSessionQuery(activeSessionId!, { skip: !activeSessionId, refetchOnMountOrArgChange: true });

  // Handle message submission from the AgentDrivenChatInput
  const handleSendMessage = useCallback((text: string, agent: string) => {
    setSelectedAgent(agent);
    onSendMessage(text, agent);
  }, [onSendMessage]);
  
  // Handle agent selection
  const handleAgentSelect = useCallback((agentId: string) => {
    setSelectedAgent(agentId);
    setSnackbarMessage(`Switched to ${agentId} agent`);
    setSnackbarOpen(true);
  }, []);
  
  // Handle stop request
  const handleStopRequest = useCallback(() => {
    if (onStopRequest) {
      onStopRequest();
      setSnackbarMessage("Generation stopped");
      setSnackbarOpen(true);
    }
  }, [onStopRequest]);
  
  // Close snackbar
  const handleSnackbarClose = useCallback(() => {
    setSnackbarOpen(false);
  }, []);

  const renderNoActiveSession = useCallback(() => (
    <Box sx={{ 
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      p: 3,
      textAlign: 'center'
    }}>
      <SmartToyIcon sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
      <Box sx={{ typography: 'h4', mb: 2, fontWeight: 'medium' }}>
        No Active Chat Selected
      </Box>
      <Box sx={{ typography: 'body1', mb: 4, maxWidth: 600, color: 'text.secondary' }}>
        Select a chat from the sidebar or start a new conversation by typing a message below.
      </Box>
    </Box>
  ), []);

  return (
    <Box sx={{ ...containerStyles, height: '100vh' }}>
      {/* Offset content for fixed TopNav AppBar */}
      <Toolbar />
       {/* Messages area - either messages or welcome screen */}
       {activeSessionId ? (
         <ChatMessageList activeAgent={selectedAgent} />
       ) : (
         <Box sx={{ flexGrow: 1 }}>
           {renderNoActiveSession()}
         </Box>
       )}
 
      {/* Input area - at bottom of interface */}
      <Box 
        sx={{ 
          pt: 2,
          pb: 2,
          width: '100%',
          position: 'fixed',
          bottom: 0,
          left: 0,
          paddingLeft: { sm: `${drawerPadding}px` },
          paddingRight: !isSmall && isCanvasOpen ? `${canvasWidth}px` : (drawerPadding ? 2 : undefined),
          zIndex: 'var(--z-input)',
          backgroundColor: 'transparent',
          backdropFilter: 'none',
          minHeight: 'var(--input-h)',
          display: 'flex',
          justifyContent: 'center',
        }}
      >
        <Container 
          maxWidth={false} 
          sx={{ 
            position: 'relative', 
            maxWidth: 720,
            width: '100%',
            mx: 'auto',
          }}
        >
          <Suspense fallback={<InputLoadingFallback />}>
            <AgentDrivenChatInput 
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
              onStopRequest={handleStopRequest}
              activeAgent={selectedAgent}
              onAgentChange={handleAgentSelect}
            />
          </Suspense>
        </Container>
      </Box>

      {/* Snackbar for agent and stop feedback */}
      <Snackbar open={snackbarOpen} autoHideDuration={3000} onClose={handleSnackbarClose}>
        <Alert onClose={handleSnackbarClose} severity="info" sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default React.memo(ChatInterface);