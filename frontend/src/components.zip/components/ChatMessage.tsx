import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../store';
import { 
  Box, 
  Typography, 
  Avatar, 
  Paper, 
  Tooltip, 
  IconButton, 
  Snackbar, 
  Chip, 
  Skeleton,
  CircularProgress,
  styled
} from '@mui/material';
import { keyframes } from '@mui/system';
import PersonIcon from '@mui/icons-material/Person';
import VolumeUpIcon from '@mui/icons-material/VolumeUp';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import ReplayIcon from '@mui/icons-material/Replay';
import ViewSidebarRoundedIcon from '@mui/icons-material/ViewSidebarRounded';
import MessageRenderer from './MessageRenderer';
import { useCanvas } from '../context/CanvasContext';
import { agentStyles } from '../constants/agentStyles';

interface ChatMessageProps {
  message: {
    id?: string;
    text: string;
    sender: 'user' | 'agent' | 'assistant' | 'system';
    timestamp: string;
  };
  isStreaming?: boolean;
  onRerun?: (text: string) => void;
  activeAgent?: string;
}

// Animation for the avatar pulse
const writingPulse = keyframes`
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.1); opacity: 0.85; }
  100% { transform: scale(1); opacity: 1; }
`;

// Pulse animation for streaming messages
const pulse = keyframes`
  0% { opacity: 0.6; }
  50% { opacity: 1; }
  100% { opacity: 0.6; }
`;

// Define the blink animation for dots with will-change for better performance
const blinkDot = keyframes`
  0%, 100% { opacity: 0.3; }
  50% { opacity: 1; }
`;

// Add a subtle cursor blink animation for streaming
const cursorBlink = keyframes`
  0%, 100% { opacity: 1; }
  50% { opacity: 0; }
`;

// Animated ellipsis after status text
const dots = keyframes`
  0% { content: '\\0000a0'; }
  33% { content: '\\. '; }
  66% { content: '\\..'; }
  100% { content: '\\...'; }
`;

const StatusText = styled('span')(() => ({
  position: 'relative',
  '&::after': {
    display: 'inline-block',
    marginLeft: 2,
    width: '0.8em',
    textAlign: 'left',
    animation: `${dots} 1.2s steps(3, end) infinite`,
  },
}));


/**
 * Displays a single chat message bubble.
 *
 * The component has deliberately been kept _dumb_ – i.e. all side-effects
 * (network calls, global state mutations, etc.) live higher up the tree.
 *
 * @param {ChatMessageProps} props – message metadata along with UI flags.
 */
const ChatMessage: React.FC<ChatMessageProps> = ({ message, isStreaming = false, onRerun, activeAgent = "general" }) => {
  const isUser = message.sender === 'user';
  // Get theme mode from Redux store or default to light
  const mode = useSelector((state: RootState) => state.app.theme) || 'light';
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [rerunSnackbarOpen, setRerunSnackbarOpen] = useState(false);
  const { openWithMessage } = useCanvas();
  const processingStatus = useSelector((state: RootState) => state.chat.processingStatus);
  const [showActions, setShowActions] = useState(false);
  // Track whether this message is currently being read aloud
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  // Debug logging for streaming state
  React.useEffect(() => {
    if (!isUser) {
      console.log(`💬 ChatMessage (${message.id}): isStreaming=${isStreaming}, processingStatus="${processingStatus}", textLength=${message.text.length}`);
    }
  }, [isStreaming, processingStatus, message.text.length, message.id, isUser]);
  
  // Get the agent styling based on activeAgent
  const agentStyle = agentStyles[activeAgent as keyof typeof agentStyles] || agentStyles.general;
  
  // Simplified canvas states
  // Flag to decide if we should render a skeleton bubble (assistant streaming but no text yet)
  const showSkeleton = !isUser && !isStreaming && message.text.trim().length === 0 && !processingStatus;
  
  // Determine if we should show action buttons for this message
  const shouldShowActions = () => {
    // Don't show for streaming messages
    if (isStreaming) return false;
    
    // Don't show for simple greetings or short system messages
    if (message.text.length < 30) return false;
    
    // For longer messages, show actions
    return true;
  };
  
  const handleCopyText = () => {
    navigator.clipboard.writeText(message.text);
    setSnackbarOpen(true);
  };
  
  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };
  
  const handleRerunSnackbarClose = () => {
    setRerunSnackbarOpen(false);
  };
  
  const handleReadAloud = () => {
    // Toggle speech synthesis for this message
    if (speechSynthesis.speaking || isSpeaking) {
      speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(message.text);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };
  
  const handleEditInCanvas = () => {
    // Open the global canvas with this message
    openWithMessage(message);
  };
  
  const handleRerunMessage = () => {
    if (isUser && onRerun) {
      onRerun(message.text);
      setRerunSnackbarOpen(true);
    }
  };
  
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        mb: { xs: 1.5, sm: 2 },
        width: '100%',
        position: 'relative',
        paddingLeft: !isUser ? 0 : 0,  // Remove left padding for assistant messages
      }}
    >
      <Box
        sx={{
          display: 'flex',
          justifyContent: isUser ? 'flex-end' : 'flex-start',
          width: '100%',
          maxWidth: {
            xs: '95%',
            sm: '85%',
            md: '75%',
            lg: '60%',
          },
          minHeight: '48px',
          pl: !isUser ? 0 : 'auto',  // Remove left padding for assistant messages
        }}
      >
      {!isUser && (
        <Box 
          sx={{ 
            display: 'flex', 
            alignItems: 'flex-start',
            mr: { xs: 1, sm: 1.5 },
            mt: 0.5,
            ml: 0,  // Ensure no left margin
          }}
        >
          <Avatar
            sx={{
              bgcolor: agentStyle.bgColor,
              color: agentStyle.color,
              border: `1px solid ${agentStyle.color}30`,
              width: { xs: 32, sm: 36 },
              height: { xs: 32, sm: 36 },
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
              boxShadow: isStreaming 
                ? `0 0 6px ${agentStyle.color}66` 
                : 'none',
              animation: isStreaming ? `${writingPulse} 1s ease-in-out infinite` : 'none'
            }}
          >
            {agentStyle.icon && agentStyle.icon}
          </Avatar>
          
          {/* Animated dots when streaming - no text */}
          {isStreaming && (
            <Box
              sx={{
                position: 'absolute',
                left: { xs: 36, sm: 42 },  // Responsive positioning
                top: { xs: 12, sm: 14 },
                display: 'flex',
                flexDirection: 'row',
                alignItems: 'center',
                gap: 0.6,
                zIndex: 5,
              }}
            >
              {processingStatus ? (
                <>
                  <CircularProgress size={12} thickness={5} sx={{ color: agentStyle.color, mr: 0.75, animationDuration: '700ms' }} />
                  <Typography variant="caption" sx={{ lineHeight: '12px', color: mode === 'dark' ? 'grey.400' : 'grey.600', fontStyle: 'italic', whiteSpace: 'nowrap' }}>
                    {processingStatus}
                    <StatusText />
                  </Typography>
                </>
              ) : (
                [0, 1, 2].map((dot) => (
                  <Box
                    key={dot}
                    component="span"
                    sx={{
                      width: '6px',
                      height: '6px',
                      borderRadius: '50%',
                      backgroundColor: mode === 'dark' ? `${agentStyle.color}dd` : agentStyle.color,
                      opacity: 0.7,
                      animation: `${blinkDot} 1.4s ease-in-out ${dot * 0.2}s infinite`,
                    }}
                  />
                ))
              )}
            </Box>
          )}
        </Box>
      )}
      
      <Box
        sx={{
          position: 'relative',
          '&:hover .message-actions': {
            opacity: 1,
            visibility: 'visible',
            transform: 'translateY(0)',
          },
        }}
        onMouseEnter={() => shouldShowActions() && setShowActions(true)}
        onMouseLeave={() => setShowActions(false)}
      >
        <Paper
          elevation={0}
          sx={{
            position: 'relative',
            maxWidth: '100%',
            width: 'fit-content',
            minWidth: '60px',
            px: 2,
            py: 1.5,
            borderRadius: 3,
            bgcolor: isUser
              ? (mode === 'dark' ? 'primary.dark' : 'primary.main')
              : (mode === 'dark' ? 'grey.800' : 'grey.100'),
            color: isUser ? 'common.white' : 'text.primary',
            wordBreak: 'break-word',
            whiteSpace: 'pre-wrap',
            overflow: 'hidden',
            transition: 'all 0.2s ease-in-out',
            border: `1px solid ${mode === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)'}`,
            '&:hover': {
              boxShadow: 2,
            },
            ...(isStreaming ? {
              borderLeft: '3px solid',
              borderLeftColor: 'primary.main',
              animation: `${pulse} 2s infinite`,
            } : {}),
          }}
        >
          {showSkeleton ? (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              <Skeleton variant="text" width="80%" />
              <Skeleton variant="text" width="70%" />
              <Skeleton variant="text" width="50%" />
            </Box>
          ) : isUser ? (
            <Typography
              variant="body1"
              component="div"
              sx={{
                fontSize: '0.95rem',
                lineHeight: 1.6,
                wordBreak: 'break-word',
                whiteSpace: 'pre-wrap',
                position: 'relative',
                // Add a blinking cursor at the end if streaming
                '&::after': isStreaming ? {
                  content: '""',
                  display: 'inline-block',
                  width: '2px',
                  height: '1.2em',
                  backgroundColor: 'currentColor',
                  marginLeft: '2px',
                  verticalAlign: 'text-bottom',
                  animation: `${cursorBlink} 0.8s infinite`,
                } : {},
              }}
            >
              {message.text}
            </Typography>
          ) : (
            <Box sx={{
              width: '100%',
              overflow: 'hidden',
              wordBreak: 'break-word',
              '& > *': {
                maxWidth: '100%',
              },
              // Ensure proper styling for markdown content
              '& p': {
                margin: '0 0 8px 0',
                lineHeight: 1.6,
              },
              '& p:last-child': {
                marginBottom: 0,
              },
              // Fix table overflow issues
              '& table': {
                width: '100%',
                maxWidth: '100%',
                borderCollapse: 'collapse',
              },
              // Fix code block issues
              '& pre': {
                overflow: 'auto',
                maxWidth: '100%',
              },
            }}>
              {/* Use the safer MessageRenderer component */}
              <MessageRenderer content={message.text} isUser={isUser} />
            </Box>
          )}
          <Typography variant="caption" sx={{ mt: 1, opacity: 0.7, display: 'block' }}>
            {(() => {
              const timestamp = typeof message.timestamp === 'string' || typeof message.timestamp === 'number' 
                ? new Date(message.timestamp) 
                : null;
              return timestamp && !isNaN(timestamp.getTime()) 
                ? timestamp.toLocaleTimeString() 
                : '';
            })()}
            {!isUser && activeAgent && (
              <Chip 
                label={
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <Box component="span">{agentStyles[activeAgent as keyof typeof agentStyles]?.name || "General Bot"}</Box>
                  </Box>
                }
                size="small" 
                sx={{ 
                  ml: 1, 
                  height: 16, 
                  fontSize: '0.6rem',
                  bgcolor: 'transparent',
                  color: mode === 'dark' ? `${agentStyle.color}dd` : agentStyle.color,
                  border: 'none',
                  '& .MuiChip-label': {
                    padding: '0 4px',
                  }
                }} 
              />
            )}
          </Typography>
          
          <Box
            className="message-actions"
            sx={{ 
              position: 'absolute',
              top: -36,
              right: isUser ? 0 : 'auto',
              left: isUser ? 'auto' : 0,
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: mode === 'dark' ? 'rgba(0,0,0,0.9)' : 'rgba(255,255,255,0.98)',
              borderRadius: 12,
              py: 0.5,
              px: 1,
              boxShadow: '0 8px 24px rgba(0,0,0,0.3)',
              opacity: showActions ? 1 : 0,
              visibility: showActions ? 'visible' : 'hidden',
              transform: showActions ? 'translateY(0)' : 'translateY(10px)',
              transition: 'all 0.2s ease-in-out',
              zIndex: 10,
              border: mode === 'dark' ? '1px solid rgba(255,255,255,0.2)' : '1px solid rgba(0,0,0,0.15)',
              '&:hover': {
                opacity: 1,
                visibility: 'visible',
                transform: 'translateY(0)',
              },
            }}
          >
            {isUser && onRerun && (
              <Tooltip title="Rerun this message">
                <IconButton size="small" onClick={handleRerunMessage}>
                  <ReplayIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            <Tooltip title="Copy to clipboard">
              <IconButton size="small" onClick={handleCopyText}>
                <ContentCopyIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            {/* Read-aloud only makes sense for non-user messages */}
            {!isUser && (
              <Tooltip title={isSpeaking ? "Stop reading" : "Read aloud"}>
                <IconButton size="small" onClick={handleReadAloud}>
                  <VolumeUpIcon fontSize="small" color={isSpeaking ? "error" : "inherit"} />
                </IconButton>
              </Tooltip>
            )}
            {!isUser && (
              <Tooltip title="Open canvas">
                <IconButton size="small" onClick={handleEditInCanvas}>
                  <ViewSidebarRoundedIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Box>
        </Paper>
      </Box>
      
      {isUser && (
        <Avatar 
          sx={{ 
            bgcolor: 'primary.main',
            ml: 1.5,
            width: 36, 
            height: 36 
          }}
        >
          <PersonIcon fontSize="small" />
        </Avatar>
      )}
      
      {/* Clipboard snackbar */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={2000}
        onClose={handleSnackbarClose}
        message="Copied to clipboard"
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
      
      {/* Rerun snackbar */}
      <Snackbar
        open={rerunSnackbarOpen}
        autoHideDuration={2000}
        onClose={handleRerunSnackbarClose}
        message="Message rerun initiated"
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
      

    </Box> {/* Close inner responsive container */}
  </Box>
  );
};

// Export as memoized component to prevent unnecessary re-renders
export default React.memo(ChatMessage);