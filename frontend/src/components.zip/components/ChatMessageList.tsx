import React, { useMemo, useEffect, useRef } from 'react';
import { Box, useTheme } from '@mui/material';
import MessageRow from './MessageRow';
import IntelligentRoutingIndicator from './IntelligentRoutingIndicator';
import { useSelector } from 'react-redux';
import { RootState } from '../store';
import type { ChatMessage as ChatMessageType } from '../features/chat/chatSlice';
import '../css/chatThread.css';
import '../css/scrollbar.css';

interface ChatMessageListProps {
  activeAgent?: string;
  messages?: ChatMessageType[];
}

// Memoized MessageRow component to prevent unnecessary re-renders
const MemoizedMessageRow = React.memo(MessageRow, (prevProps, nextProps) => {
  return (
    prevProps.msg.id === nextProps.msg.id &&
    prevProps.msg.text === nextProps.msg.text &&
    prevProps.isStreaming === nextProps.isStreaming &&
    prevProps.sameSender === nextProps.sameSender
  );
});

const ChatMessageList: React.FC<ChatMessageListProps> = ({ activeAgent, messages: externalMessages }) => {
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Memoized selectors for performance
  const chatState = useSelector((state: RootState) => ({
    activeSessionId: state.chat.activeSessionId,
    sessions: state.chat.sessions,
    isLoading: state.chat.isLoading,
    currentAssistantMessageId: state.chat.currentAssistantMessageId,
    routingMetadata: state.chat.routingMetadata
  }), (prev, next) => {
    // Custom equality check for better performance
    return (
      prev.activeSessionId === next.activeSessionId &&
      prev.isLoading === next.isLoading &&
      prev.currentAssistantMessageId === next.currentAssistantMessageId &&
      prev.sessions.length === next.sessions.length
    );
  });

  const { activeSessionId, sessions, isLoading, currentAssistantMessageId, routingMetadata } = chatState;
  
  // Memoize the active session and messages to prevent unnecessary re-renders
  const activeSession = useMemo(() => {
    return sessions.find(session => session.id === activeSessionId);
  }, [sessions, activeSessionId]);
  
  const messages = useMemo(() => {
    if (externalMessages) return externalMessages;
    return activeSession?.messages || [];
  }, [activeSession, externalMessages]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  return (
    <Box
      className="thread"
      sx={{
        flex: '1 1 auto',
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      {/* Scrollable message column */}
      <Box className="chat-messages" sx={{ 
        flex: '1 1 auto', 
        overflowY: 'auto',
        pl: 0,
        pr: { xs: 1, sm: 2 },
        py: { xs: 2, sm: 3 },
        '&::-webkit-scrollbar': {
          width: '8px',
        },
        '&::-webkit-scrollbar-track': {
          background: 'transparent',
        },
        '&::-webkit-scrollbar-thumb': {
          background: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.2)',
          borderRadius: '4px',
          '&:hover': {
            background: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.3)' : 'rgba(0,0,0,0.3)',
          },
        },
      }}>
        {messages.length === 0 ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              height: '100%',
              textAlign: 'center',
              color: 'text.secondary',
              p: 4,
            }}
          >
            <Box sx={{ 
              fontSize: '4rem', 
              mb: 2,
              background: 'linear-gradient(135deg, #C60C30, #E31937)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              💬
            </Box>
            <Box sx={{ 
              fontSize: '1.5rem', 
              fontWeight: 600, 
              mb: 1,
              color: isDark ? '#F4F6F8' : '#1f1f1f',
            }}>
              Start the conversation
            </Box>
            <Box sx={{ 
              fontSize: '1rem',
              color: isDark ? 'rgba(244, 246, 248, 0.7)' : 'rgba(31, 31, 31, 0.7)',
            }}>
              Ask me anything - I'm here to help!
            </Box>
          </Box>
        ) : (
          <>  {/* Render messages using MessageRow */}
            {routingMetadata && <IntelligentRoutingIndicator />}
            {messages.map((message, index) => {
              const validMessage = {
                id: message.id || `msg-${index}`,
                text: message.text || '',
                sender: message.sender || 'assistant',
                timestamp: message.timestamp || new Date().toISOString(),
              };
              const isCurrentlyStreaming = isLoading && currentAssistantMessageId === validMessage.id;
              const sameSender = index > 0 && messages[index - 1]?.sender === validMessage.sender;
              
              return (
                <MemoizedMessageRow
                  key={validMessage.id}
                  msg={validMessage}
                  isStreaming={isCurrentlyStreaming}
                  sameSender={sameSender}
                />
              );
            })}
            <div ref={messagesEndRef} />
          </>
        )}
      </Box>
    </Box>
  );
};

export default React.memo(ChatMessageList);