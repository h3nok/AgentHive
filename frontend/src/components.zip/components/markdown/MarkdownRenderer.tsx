// src/components/markdown/MarkdownRenderer.tsx
// -----------------------------------------------------------------------------
// A lightweight, plugin-driven renderer that converts Markdown (and fenced
// blocks) into rich React components – charts, tables, SQL editors, etc.
// -----------------------------------------------------------------------------
// Usage:
//   <MarkdownRenderer markdown={assistantText} />
//     • Automatically renders GitHub-flavoured Markdown (remark-gfm)
//     • Recognises fenced blocks with language tags: ``sql``, ``table``,
//       ``chart``, etc. – via the plugin registry below.
//     • Each heavy dependency (react-syntax-highlighter, apexcharts,
//       data-grid) is **lazy-loaded**, so the base bundle stays tiny.

import React, { lazy, Suspense, ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Components } from 'react-markdown';
import { Box, CircularProgress, useTheme } from '@mui/material';
import yaml from 'js-yaml';

// -----------------------------------------------------------------------------
// ⭐ 1. Types & helpers
// -----------------------------------------------------------------------------
export interface MdPlugin {
  /** Return true if the fenced‐code info string matches this plugin */
  test: (infoString: string) => boolean;
  /** Render the contents of the fence block */
  render: (literal: string) => ReactNode;
}

const Loading: React.FC = () => (
  <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
    <CircularProgress size={24} />
  </Box>
);

// -----------------------------------------------------------------------------
// ⭐ 2. SQL plugin (lazy-loads syntax highlighter + SQL UI)
// -----------------------------------------------------------------------------
const SqlCode = lazy(() => import('./plugins/SqlCode'));
const sqlPlugin: MdPlugin = {
  test: (info) => info.trim().toLowerCase() === 'sql',
  render: (literal) => (
    <Suspense fallback={<Loading />}>
      <SqlCode code={literal} />
    </Suspense>
  ),
};

// -----------------------------------------------------------------------------
// ⭐ 3. Table plugin  –  uses DataGrid when Markdown‐table syntax detected
// -----------------------------------------------------------------------------
const DataGridTable = lazy(() => import('./plugins/DataGridTable'));
const tablePlugin: MdPlugin = {
  test: (info) => info.trim().toLowerCase() === 'table',
  render: (literal) => (
    <Suspense fallback={<Loading />}>
      <DataGridTable markdown={literal} />
    </Suspense>
  ),
};

// -----------------------------------------------------------------------------
// ⭐ 4. Chart plugin – supports YAML front-matter in the fenced block
// -----------------------------------------------------------------------------
const ChartFactory = lazy(() => import('./plugins/ChartFactory'));
const chartPlugin: MdPlugin = {
  test: (info) => info.trim().toLowerCase().startsWith('chart'),
  render: (literal) => {
    let cfg: any = {};
    try {
      // Expect YAML front-matter at the top of the literal
      cfg = yaml.load(literal) || {};
    } catch {
      /* invalid YAML → ignore and pass empty config */
    }
    return (
      <Suspense fallback={<Loading />}>
        <ChartFactory {...cfg} />
      </Suspense>
    );
  },
};

// -----------------------------------------------------------------------------
// ⭐ 5. Plugin registry – order matters (first match wins)
// -----------------------------------------------------------------------------
const plugins: MdPlugin[] = [sqlPlugin, tablePlugin, chartPlugin];

// -----------------------------------------------------------------------------
// ⭐ 6. Core MarkdownRenderer component
// -----------------------------------------------------------------------------
export interface MarkdownRendererProps {
  markdown: string | undefined;
  components?: Partial<Components>; // allow callers to override default renderers
}

const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ markdown = '', components = {} }) => {
  const theme = useTheme();
  const isDark = theme.palette.mode === 'dark';

  // Custom `code` handler: if it's a fenced block, check plugins first
  const codeComponent: Components['code'] = ({ inline, children, className, node }) => {
    if (inline) {
      // Inline code simply render normally
      return <code className={className}>{children}</code>;
    }

    // Extract the “info string” (language) from className or MDAST node data
    const fenceInfo =
      (node as any)?.data?.meta ?? (className ?? '').replace('language-', '');
    const literal = String(children);

    // Try to find a plugin that handles this fenceInfo
    const plug = plugins.find((p) => p.test(fenceInfo));
    if (plug) {
      return <>{plug.render(literal)}</>;
    }

    // No plugin matched: fall back to generic syntax highlighting
    const Highlighter = lazy(() => import('./plugins/CodeHighlighter'));
    return (
      <Suspense fallback={<Loading />}>
        <Highlighter language={fenceInfo} literal={literal} dark={isDark} />
      </Suspense>
    );
  };

  // Merge with any user‐supplied overrides
  const mergedComponents: Components = {
    // Ensure code blocks render in a full-width container for DataGrid
    pre: ({ children }) => <Box sx={{ width: '100%' }}>{children}</Box>,
    code: codeComponent,
    ...components,
  };

  return (
    <ReactMarkdown remarkPlugins={[remarkGfm]} components={mergedComponents}>
      {markdown}
    </ReactMarkdown>
  );
};

export default MarkdownRenderer;
